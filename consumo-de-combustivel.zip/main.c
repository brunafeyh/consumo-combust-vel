#include <stdio.h>

int main()
{
    float consumomedio, distanciat, litros;
    
    printf("Digite a distancia percorrida e o total de combustível gasto:\n");
    scanf("%f %f", &distanciat, &litros);
    consumomedio= distanciat/litros;
    printf("O consumo medio do automóvel é: %.3f Km/L", consumomedio);

    return 0;
}
